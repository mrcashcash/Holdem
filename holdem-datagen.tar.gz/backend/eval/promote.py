"""Champion promotion gate: only checkpoints that prove themselves reach the table.

The latest training checkpoint is promoted to ``champion.npz`` only if it
does not regress against the incumbent champion on two measurements:

1. Styles benchmark (duplicate deals, same seeds every evaluation): the
   candidate's mean bb/100 must be at least (champion mean - margin).
2. Abstract-game exploitability (CFR-BR gate): at most champion x 1.25.

The champion's own scores are cached in champion_meta.json so each promotion
evaluates only the candidate. The serving agent prefers champion.npz when it
exists, so the table can never silently regress just because training wrote
a newer (possibly worse) checkpoint.

CLI:  python -m backend.eval.promote [--hands 150] [--force]
"""

from __future__ import annotations

import argparse
import json
import shutil
import statistics

from backend.solver.gpu import train as gpu_train

CHAMPION_PATH = gpu_train.DATA_DIR / "champion.npz"
CHAMPION_META_PATH = gpu_train.DATA_DIR / "champion_meta.json"

GATE_STYLES = ("calling_station", "maniac", "tight_aggressive", "nit")
STYLES_SEED = 3
# Calibrated 2026-07-19 from a 1000-hand A/B: at ~150 hands/style the
# benchmark noise is ~±250 bb/100, dwarfing a 50 margin (coin-flip verdicts).
# 300 hands + 120 margin keeps the gate fast with far fewer false verdicts.
# 3000 hands/style shrinks the CI to ~±25 bb/100 (vs ~±250 at 150), so
# comparison verdicts are statistical, not coin flips (user directive
# 2026-07-21). The tighter sample lets the mean margin drop too.
MEAN_MARGIN_BB100 = 40.0
EXPLOIT_RATIO_LIMIT = 1.25
DEFAULT_GATE_HANDS = 3000


def _depth_paths(data_dir):
    """(checkpoint, champion, meta, telemetry) for a depth's artifact dir."""
    return (
        data_dir / "checkpoint.npz",
        data_dir / "champion.npz",
        data_dir / "champion_meta.json",
        data_dir / "telemetry.json",
    )


def evaluate_checkpoint(checkpoint_path, hands: int = 150, telemetry_path=None) -> dict:
    """Styles mean (at the agent's trained depth) + exploitability for a checkpoint."""
    from backend.agents.gpu_blueprint_agent import GpuBlueprintAgent
    from backend.eval.benchmark import benchmark_against_styles

    agent = GpuBlueprintAgent.try_load(checkpoint_path)
    if agent is None:
        raise FileNotFoundError(checkpoint_path)
    agent.subgame_search = False  # gate on blueprint strength; search is a separate layer
    stack_bb = float(agent.tree.config.stack_bb)
    report = benchmark_against_styles(
        agent, hands_per_style=hands, styles=GATE_STYLES, seed=STYLES_SEED, stack_bb=stack_bb
    )

    # Read the trainer's own logged CFR-BR value from THIS depth's telemetry
    # (never recompute on the GPU — evaluation must not contend for VRAM).
    exploitability = None
    telemetry_path = telemetry_path or gpu_train.TELEMETRY_PATH
    if telemetry_path.exists():
        history = json.loads(telemetry_path.read_text(encoding="utf-8"))
        readings = [r["exploitability_mbb_per_hand"] for r in history if r.get("exploitability_mbb_per_hand") is not None]
        if readings:
            exploitability = readings[-1]
    return {
        "iteration": agent.iteration,
        "stack_bb": stack_bb,
        "styles_mean_bb_per_100": report["mean_bb_per_100"],
        "styles": {name: entry["bb_per_100"] for name, entry in report["styles"].items()},
        "exploitability_mbb": round(exploitability, 2) if exploitability is not None else None,
        "hands_per_style": hands,
    }


def promote_if_better(hands: int = 150, force: bool = False, progress: bool = True, data_dir=None) -> dict:
    data_dir = data_dir or gpu_train.DATA_DIR
    checkpoint_path, champion_path, meta_path, telemetry_path = _depth_paths(data_dir)
    candidate = evaluate_checkpoint(checkpoint_path, hands=hands, telemetry_path=telemetry_path)
    champion_meta = None
    if meta_path.exists():
        champion_meta = json.loads(meta_path.read_text(encoding="utf-8"))

    if champion_meta is not None and not force:
        mean_ok = candidate["styles_mean_bb_per_100"] >= champion_meta["styles_mean_bb_per_100"] - MEAN_MARGIN_BB100
        cand_exp = candidate["exploitability_mbb"]
        champ_exp = champion_meta.get("exploitability_mbb")
        # Exploitability check only when both sides have a comparable reading.
        exploit_ok = cand_exp is None or champ_exp is None or cand_exp <= max(champ_exp * EXPLOIT_RATIO_LIMIT, 50.0)
        promoted = mean_ok and exploit_ok
    else:
        promoted = True
        mean_ok = exploit_ok = True

    verdict = {
        "promoted": promoted,
        "candidate": candidate,
        "champion": champion_meta,
        "mean_ok": mean_ok,
        "exploit_ok": exploit_ok,
    }
    if promoted:
        shutil.copy2(checkpoint_path, champion_path)
        meta_path.write_text(json.dumps(candidate, indent=2), encoding="utf-8")
    if progress:
        print(json.dumps(verdict, indent=2))
    return verdict


def main() -> None:
    parser = argparse.ArgumentParser(description="Promote the latest checkpoint if it beats the champion")
    parser.add_argument("--hands", type=int, default=DEFAULT_GATE_HANDS)
    parser.add_argument("--force", action="store_true", help="promote unconditionally")
    parser.add_argument("--stack-bb", type=float, default=100.0, help="which depth's blueprint to gate")
    arguments = parser.parse_args()
    data_dir = gpu_train.DATA_DIR
    if arguments.stack_bb != 100.0:
        data_dir = gpu_train.DATA_DIR.parent / f"gpu_blueprint_{int(arguments.stack_bb)}bb"
    promote_if_better(hands=arguments.hands, force=arguments.force, data_dir=data_dir)


if __name__ == "__main__":
    main()
